package stepdefinitions;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class StepDefinition {
    public  WebDriver driver;
    static final String APP_URL="https://www.google.co.in";
    static final String HOST_URL="http://localhost:4444/wd/hub";

    private String scenDesc;

    @Before
    public void before(Scenario scenario) {
        this.scenDesc = scenario.getName();
        ChromeOptions opt =new ChromeOptions();
//        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
try{
    driver=new RemoteWebDriver(new URL(HOST_URL),opt);
}catch (MalformedURLException e){
    e.printStackTrace();
}
    }

    @BeforeStep
    public void beforeStep() throws InterruptedException {
        Thread.sleep(2000);
    }


    @When("user launches the application")
    public void user_launches_the_application() throws InterruptedException {

//        driver = new ChromeDriver();
        driver.get(APP_URL);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        driver.navigate().to("https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp");
        driver.findElement(By.id("firstName")).sendKeys("1");
        driver.findElement(By.id("lastName")).sendKeys("2");
        driver.findElement(By.id("username")).sendKeys("3");
        driver.findElement(By.name("Passwd")).sendKeys("4");
        driver.findElement(By.name("ConfirmPasswd")).sendKeys("4");
        Thread.sleep(5000);
        System.out.format("Thread %2d -> %18s\n", Thread.currentThread().getId(), scenDesc);
        driver.quit();
    }

    @Given("Step from {string} in {string} feature file")
    public void stepFromScenarioInScenariosFeatureFile(String test, String test1) {
        System.out.format("Thread %2d -> %18s\n", Thread.currentThread().getId(), scenDesc);

    }
};
