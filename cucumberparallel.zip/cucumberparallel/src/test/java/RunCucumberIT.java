import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)

@CucumberOptions(
        features = {"src/test/resources"},
        glue = {"stepdefinitions"},
        monochrome = true
//        tags = {"@contactus"},
//        dryRun = false,
//        strict = true
)
public class RunCucumberIT {
    @BeforeClass
    public static void  before() {
        System.out.println("START - " +System.currentTimeMillis() );
    }

    @AfterClass
    public static void after() {
        System.out.println("END - " +System.currentTimeMillis() );
    }
}



