Thank you for downloading the TestingBot Tunnel v.3.0
You can find more information about this program on https://testingbot.com/support/other/tunnel

To get started, make sure you have Java installed.
Find your TestingBot Key and Secret from the TestingBot member dashboard.

export TB_KEY=...
export TB_SECRET=...
Then open a command prompt and type: java -jar testingbot-tunnel.jar
